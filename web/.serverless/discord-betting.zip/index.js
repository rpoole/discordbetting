const Koa = require('koa');
const app = new Koa();
const serverless = require('serverless-http');

app.use(ctx => {
    ctx.body = 'sup';
});

module.exports.handler = serverless(app);
