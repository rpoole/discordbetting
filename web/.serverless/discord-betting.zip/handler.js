const Koa = require('koa');
const app = new Koa();
const serverless = require('serverless-http');

app.use(ctx => {
    ctx.body = 'hi';
});

app.use(async (ctx, next) => {
    const start = Date.now();
    await next();
    const ms = Date.now() - start;
    console.log(`${ctx.method} ${ctx.url} - ${ms}ms`);
});

module.exports.handler = serverless(app);
